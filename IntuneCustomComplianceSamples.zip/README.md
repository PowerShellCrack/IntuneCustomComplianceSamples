# Intune Custom Compliance Samples

These are sample script for Intune Custom Compliance policies

## Reference:
https://learn.microsoft.com/en-us/mem/intune/protect/compliance-custom-json


## How to use them

1. Login into [Intune Admin Center](https://intune.microsoft.com)
2. Navigate to 